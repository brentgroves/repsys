extern void msgprintf (const char *fmt);
extern void msgprintf (const char *fmt, int v1);
extern void msgprintf (const char *fmt, size_t v1);
extern void msgprintf (const char *fmt, const char *v1, int v2, int v3);
extern void msgprintf (const char *fmt, const char *v1, int v2, int v3, const char *v4);
extern void msgprintf (const char *fmt, int v1, int v2, const void *v3, int v4, const void *v5);
extern void msgprintf (const char *fmt, int v1, int v2, int v3, int v4, int v5, const void *v6, int v7, const void *v8);
