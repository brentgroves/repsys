     README
     Progress DataDirect
     DataDirect OpenAccess SDK Client for ODBC
     Version 8.1
     March 2021

***********************************************************************
Copyright (C) 1995-2021 Progress Software Corporation. All rights reserved.
DataDirect and OpenAccess are trademarks or registered trademarks of 
Progress Software Corporation in the U.S. and other countries. Any 
other trademarks or service marks contained herein are the property 
of their respective owners.
***********************************************************************
This README file contains information not included in the DATADIRECT 
OPENACCESS(TM) SDK documentation.

IMPORTANT: You must have the Microsoft Data Access Components (MDAC) 
installed to use this product.
* For 32-bit Windows systems, version 2.6 or later is required.
* For 64-bit Windows systems, version 2.8 or later is required.
Depending on the version of your Windows operating system, these 
components may already be installed. You can download a utility that 
determines whether MDAC is installed and its version from the following 
Microsoft site:
http://msdn.microsoft.com/en-us/data/aa937730.aspx
You can also download MDAC from the same site.

CONTENTS
Installation Directory
Certifications
Disk Space Requirements
Notes, Known Problems, and Restrictions
Documentation
Installed Files

     Installation Directory
* The default installation directory on Windows for DataDirect 
  SDK Client for ODBC is:
  C:\Program Files\Progress\DataDirect\oaodbc81

    Certifications

* The OpenAccess SDK Client for ODBC (64-bit) has been certified with 
  Red Hat Enterprise 8.0.
  
  OpenAccess SDK version 8.1.0.0131

* The OpenAcess SDK Client for ODBC has been certified with 
  Windows Server 2019.
  
  OpenAccess SDK version 8.1.0.0129

* The OpenAcess SDK Client for ODBC has been certified with Windows 10.

* The OpenAcess SDK Client for ODBC has been certified with Linux Suse 12.

* The OpenAcess SDK Client for ODBC has been certified with Linux RHL 7.0.

* The OpenAcess SDK Client for ODBC has been certified with AIX 7.2.

    Disk Space Requirements
windows 32-bit client       :  77  MB
windows 64-bit client       :  100 MB
Linux/Unix  32-bit client   :  64 MB
Linux/Unix  64-bit client   :  67 MB

     Notes, Known Problems, and Restrictions

The following are notes, known problems, or restrictions with 
Release 8.1 of the DataDirect OpenAccess SDK Client for ODBC:

* The OpenAccess SDK HTML Help may not work well with Google Chrome. 
  Please use a different browser.

     Documentation
The DataDirect OpenAccess SDK books are provided in PDF and 
HTML versions. Both PDF and HTML versions are available on the 
Progress Information Hub:

https://docs.progress.com/category/datadirect-openaccess-sdk

The HTML version is also installed in the help subdirectory 
of your product installation directory.
     Installed Files
Installed Files for Windows(32-bit & 64-bit)
--------------------------------------------
The installer copies the following files and subdirectories to the 
product installation directory, by default,
C:\Program Files\Progress\DataDirect\oaodbc81:

notices.txt             Third-party vendor license agreements.
fixes.txt               List of fixes since last release.
license.txt             OpenAccess SDK - End User License Agreement
readme.txt              This file.
icudt42.dll             Unicode conversion tables.
iculicense.htm          ICU license file.
icuuc42.dll             Unicode conversion tables.
ivldap27.dll            Support dll for LDAP.
ivmgan27.dll            Anonymous authentication MGSS module.
ivmghu27.dll            Host User authentication MGSS module.
ivmgsp27.dll            SSPI (NTLM or Kerberos) authentication MGSS module.
ivoa27.dll              OpenAccess 8.1.0 for ODBC driver file.
ivoa27.ini              OpenAccess 8.1.0 for ODBC driver config file.
ivoa27m.dll             OpenAccess 8.1.0 for ODBC driver message file.
ivoad27.dll             OpenAccess 8.1.0 for ODBC driver dialog file.
ivoas27.dll             OpenAccess 8.1.0 for ODBC driver setup file.
oaodbc[32|64].lic       OpenAccess ODBC driver license file.
openassllicense.txt     OpenSSL license file.
openssl810.dll          OpenSSL file.
openldaplicense.txt     openLDAP license file.
odbcisql.ini            odbcisql config file.
odbcisql.exe            Interactive SQL (ODBC).
whatmain.exe            Version info tool.
oaencpwd.exe            Password encryption tool.
ddextwin.exe            License extension tool.
qesqlext.h              DataDirect sqlext.h file.

\custom
\custom\branding        Branding tool.
\custom\install         install sources.
\custom\messages        message files for localization.
\custom\setup           custom setup odbc driver sources.
\help
help.htm                Html help system entry file.
wwhsec.htm              Html help system support file.
\*.*                    Support folders for the html help system.
\samples 
\bulk                   Bulk sample.
\bulkstrm               Bulk streaming example.
\tableau\OpenAccess.tdc Tableau Table datasource connection (TDC) file.

Installed Files for UNIX(32-bit & 64-bit)
-----------------------------------------
The installer copies the following files and subdirectories to the 
product installation directory
notices.txt             Third-party vendor license agreements.
fixes.txt               List of fixes since last release.
license.txt             OpenAccess SDK - End User License Agreement
readme.txt              This file.
license.txt             DataDirect EULA.
openldaplicense.txt LDAP  license file.
openssllicense.txt      OpenSSL license file.
iculicense.txt          ICU license file.

oaodbc.sh               DSN configuration file.
oaodbc.csh

OAODBC32(64).LIC        License file.

/lib
ivldap27.so             Support library for LDAP.
ivmgan27.so             Anonymous Authentication MGSS module.
ivmghu27.so             Host User Authentication MGSS module.
ivmgapi27.so            SSPI (Kerberos) Authentication MGSS module.
ivoa27.so               OpenAccess 8.1.0 for ODBC driver file. 
ivoa27.ini              OpenAccess 8.1.0 for ODBC driver file.
ivtrc27.so              DataDirect trace library.
ddtrc27.so              DataDirect trace library(64-bit).
openssl810.so           OpenSSL file.
libicudata.so.42        ICU file.
libicuuc.so.42          ICU file.
libivicu27.so           ICU file.
libodbc.so              DataDirect driver manager file.
libodbcinst.so      
odbccurs.so     
libivicu27.so           ICU file for the ODBC DataDirect Driver Manager.
libivoa27m.so           ODBC driver message file that can be localized.
libddicu27.so           ICU file for the ODBC DataDirect Driver Manager.


/include
*.h                     DataDirect DriverManager and sql defines.

/locale
  en_US                 Message file.

/samples
/samples/example        example sample.
/samples/bulk           bulk sample.
/samples/bulkstrm       bulk stream sample.
    
/custom
/custom/setup
/custom/branding
/custom/messages

/tools
ivcheckcp               DataDirect version tool.
tstk5gss                Kerberos tool.
odbcisql.ini            Interactive SQL (ODBC) config file.
ivtestlib               Testtool.
odbcisql                Interactive SQL (ODBC).
oaencpwd                Password encryption tool.
ddext                   License extension tool.
whatmain                Whatmain utility.
Note:
On HP-UX PARISC platform, please note that files with .so extension are shipped 
with .sl extension 
-----------------------------------------------------------------------------
End of README

