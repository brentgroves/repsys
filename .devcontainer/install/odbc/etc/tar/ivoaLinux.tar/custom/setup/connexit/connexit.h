#if defined(_WINDOWS)

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CONNEXIT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CONNEXIT_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef CONNEXIT_EXPORTS
#define CONNEXIT_API __declspec(dllexport)
#else
#define CONNEXIT_API __declspec(dllimport)
#endif

#else
#define CONNEXIT_API
#endif

#include <sql.h>

#ifdef __cplusplus
extern "C" {
#endif /* C++ */

extern CONNEXIT_API SQLRETURN
SQLConnectW_Enter(
	SQLHDBC hdbc, 
	SQLWCHAR *szDSN, 
	SQLSMALLINT cbDSN, 
	SQLWCHAR *szUID, 
	SQLSMALLINT cbUID, 
	SQLWCHAR *szAuthStr, 
	SQLSMALLINT cbAuthStr,
	SQLWCHAR **pszDSNOverride, 
	SQLSMALLINT *pcbDSNOverride, 
	SQLWCHAR **pszUIDOverride, 
	SQLSMALLINT *pcbUIDOverride, 
	SQLWCHAR **pszAuthStrOverride, 
	SQLSMALLINT *pcbAuthStrOverride);

extern CONNEXIT_API SQLRETURN 
SQLConnectW_Exit(
	SQLWCHAR *szDSNOverride, 
	SQLSMALLINT cbDSNOverride, 
	SQLWCHAR *szUIDOverride, 
	SQLSMALLINT cbUIDOverride, 
	SQLWCHAR *szAuthStrOverride, 
	SQLSMALLINT cbAuthStrOverride);

extern CONNEXIT_API SQLRETURN 
SQLDriverConnectW_Enter(
	SQLHDBC hdbc, 
	SQLHWND hwnd, 
	SQLWCHAR *szConnStrIn, 
	SQLSMALLINT cbConnStrIn, 
	SQLWCHAR *szConnStrOut, 
	SQLSMALLINT cbConnStrOutMax, 
	SQLUSMALLINT fDriverCompletion,
	SQLWCHAR **pszConnStrInOverride, 
	SQLSMALLINT *pcbConnStrInOverride, 
	SQLUSMALLINT *pfDriverCompletionOverride);

extern CONNEXIT_API SQLRETURN 
SQLDriverConnectW_Exit(
	SQLWCHAR *szConnStrInOverride, 
	SQLSMALLINT cbConnStrInOverride);

#ifdef __cplusplus
}
#endif /* C++ */


