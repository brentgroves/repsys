The driver has been augmented with a facility to change connection information on calls to SQLConnectW and SQLDriverConnectW.

The client application must supply a custom shared library ("connexit.dll" on Windows, "connexit.so" on Unix), exporting the follow functions :

extern "C" SQLRETURN
SQLConnectW_Enter(
     SQLHDBC hdbc, 
     SQLWCHAR *szDSN, 
     SQLSMALLINT cbDSN, 
     SQLWCHAR *szUID, 
     SQLSMALLINT cbUID, 
     SQLWCHAR *szAuthStr, 
     SQLSMALLINT cbAuthStr,
     SQLWCHAR **pszDSNOverride, 
     SQLSMALLINT *pcbDSNOverride, 
     SQLWCHAR **pszUIDOverride, 
     SQLSMALLINT *pcbUIDOverride, 
     SQLWCHAR **pszAuthStrOverride, 
     SQLSMALLINT *pcbAuthStrOverride);

extern "C" SQLRETURN 
SQLConnectW_Exit(
     SQLWCHAR *szDSNOverride, 
     SQLSMALLINT cbDSNOverride, 
     SQLWCHAR *szUIDOverride, 
     SQLSMALLINT cbUIDOverride, 
     SQLWCHAR *szAuthStrOverride, 
     SQLSMALLINT cbAuthStrOverride);

extern "C" SQLRETURN 
SQLDriverConnectW_Enter(
     SQLHDBC hdbc, 
     SQLHWND hwnd, 
     SQLWCHAR *szConnStrIn, 
     SQLSMALLINT cbConnStrIn, 
     SQLWCHAR *szConnStrOut, 
     SQLSMALLINT cbConnStrOutMax, 
     SQLUSMALLINT fDriverCompletion,
     SQLWCHAR **pszConnStrInOverride, 
     SQLSMALLINT *pcbConnStrInOverride, 
     SQLUSMALLINT *pfDriverCompletionOverride);

extern "C" SQLRETURN 
SQLDriverConnectW_Exit(
     SQLWCHAR *szConnStrInOverride, 
     SQLSMALLINT cbConnStrInOverride);

The functions SQLConnectW_Enter and SQLDriverConnectW_Enter are called directly after the genuine SQLConnectW and SQLDriverConnectW function entry point.
If SQLConnectW_Enter and SQLDriverConnectW_Enter return an error, this error is returned immediately to the application. Note that it is not possible to obtain error information using the ODBC error diagnostic functions for these errors.

The functions SQLConnectW_Enter and SQLDriverConnectW_Enter then return modified output into the respective xxxOverride parameters, and the original SQLConnectW and SQLDriverConnectW continue as if the application has specified the xxxOverride information.
Memory allocation as needed by th xxxOverride parameters is entirely under the control of the �connexit� shared library.

After complete execution of the function but just before returning the returncode to the application, SQLConnect and SQLDriverConnectW call the functions SQLConnectW_Exit and SQLDriverConnectW_Exit functions, passing the xxxOverride parameters to the �connexit� shared library. This allows the shared library to free up any resources it may have used.

It is up to the implementer of the �connexit�  library to ensure or enforce the use of this library, one possibility we can think of is passing a �CustomProperties� key-value pair to the IP.

There are important security concerns. An attacker is very capable of replacing the customer�s instance of the shared library with something that captures (even stealth) or overrides userid/password information, manipulate other logon information, even hijack the database connection.
Therefore, the SQLConnectW and SQLDriverConnectW intercept / modify is only available on branded drivers, where the customer explicitly must explicitly turn on the feature using the branding tool � also taking the responsibility.
 
