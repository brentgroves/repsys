// connexit.cpp : Defines the exported functions for the DLL application.
//
#if defined(_WINDOWS)
#include "stdafx.h"
#endif
#include "connexit.h"

extern "C" CONNEXIT_API SQLRETURN 
SQLConnectW_Enter(
	SQLHDBC hdbc, 
	SQLWCHAR *szDSN, 
	SQLSMALLINT cbDSN, 
	SQLWCHAR *szUID, 
	SQLSMALLINT cbUID, 
	SQLWCHAR *szAuthStr, 
	SQLSMALLINT cbAuthStr,
	SQLWCHAR **pszDSNOverride, 
	SQLSMALLINT *pcbDSNOverride, 
	SQLWCHAR **pszUIDOverride, 
	SQLSMALLINT *pcbUIDOverride, 
	SQLWCHAR **pszAuthStrOverride, 
	SQLSMALLINT *pcbAuthStrOverride) {
		*pszDSNOverride = szDSN;
		*pcbDSNOverride = cbDSN;
		*pszUIDOverride = szUID;
		*pcbUIDOverride = cbUID;
		*pszAuthStrOverride = szAuthStr;
		*pcbAuthStrOverride = cbAuthStr;
		return SQL_SUCCESS;
}

extern "C" CONNEXIT_API SQLRETURN 
SQLConnectW_Exit(
	SQLWCHAR *szDSNOverride, 
	SQLSMALLINT cbDSNOverride, 
	SQLWCHAR *szUIDOverride, 
	SQLSMALLINT cbUIDOverride, 
	SQLWCHAR *szAuthStrOverride, 
	SQLSMALLINT cbAuthStrOverride) {
		return SQL_SUCCESS;
}

extern "C" CONNEXIT_API SQLRETURN 
SQLDriverConnectW_Enter(
	SQLHDBC hdbc, 
	SQLHWND hwnd, 
	SQLWCHAR *szConnStrIn, 
	SQLSMALLINT cbConnStrIn, 
	SQLWCHAR *szConnStrOut, 
	SQLSMALLINT cbConnStrOutMax, 
	SQLUSMALLINT fDriverCompletion,
	SQLWCHAR **pszConnStrInOverride, 
	SQLSMALLINT *pcbConnStrInOverride, 
	SQLUSMALLINT *pfDriverCompletionOverride) {
		*pszConnStrInOverride = szConnStrIn;
		*pcbConnStrInOverride = cbConnStrIn;
		*pfDriverCompletionOverride = fDriverCompletion;
		return SQL_SUCCESS;
}

extern "C" CONNEXIT_API SQLRETURN 
SQLDriverConnectW_Exit(
	SQLWCHAR *szConnStrInOverride, 
	SQLSMALLINT cbConnStrInOverride) {
		return SQL_SUCCESS;
}
