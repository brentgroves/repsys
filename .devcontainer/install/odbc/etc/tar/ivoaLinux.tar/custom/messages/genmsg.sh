# !bin/ksh
# DataDirect OpenAccess SDK Server and IP SDK - Message builder
#(c) 1995-2016. Progress Software Corporation. All Rights Reserved.
# $Revision:   1.12  $
#

OAINSTALLDIR="/usr/oaserver81"
ICUTOP="$OAINSTALLDIR/custom/messages/icu"

SRCDIR="$OAINSTALLDIR/custom/messages/languages"
DSTDIR="$OAINSTALLDIR/custom/messages/release"

# set ICU tools related variables
LD_LIBRARY_PATH="$ICUTOP/lib"
export LD_LIBRARY_PATH

ICUBIN="$ICUTOP/bin"
BLDOPT="$ICUTOP/lib/icu/current/pkgdata.inc"

# platform dependent
MSGEXT=so
XARFLAGS="xv"
UNAME=`uname`

# HPUX platform dependent
HPARCH=`uname -m`
if [ "${HPARCH}" != "ia64"  -a  "${UNAME}" = "HP-UX" ] ;  then 
  MSGEXT=sl
fi

# pkgdata input
RESLIST="${SRCDIR}/reslist.txt"
MSG_BASENAME=ivoa27m

if [ ! -d "${DSTDIR}" ] ; then
  mkdir  "${DSTDIR}"
fi

# 1. start generating the resource files

cat /dev/null > "${RESLIST}"

# generate the mandatory resource file root.res
"$ICUBIN/genrb" -d ${DSTDIR} -s ${SRCDIR} root.txt
echo "root.res" >> "${RESLIST}"

# in comment because en.txt is a subset of root.txt
# "$ICUBIN/genrb" -d "${DSTDIR}" -s ${SRCDIR} en.txt
# echo "en.res" >> "${RESLIST}"

# add an extra command for each language, f.e. fr(ench) or ja(panese)
# make sure the language files are stored in UTF-8 format with BOM
# add the resource file name for each language to reslist.txt

# "$ICUBIN/genrb" -d "${DSTDIR}" -s "${SRCDIR}" fr.txt
# echo "fr.res" >> "${RESLIST}"

# "$ICUBIN/genrb" -d "${DSTDIR}" -s "${SRCDIR}" ja.txt
# echo "ja.res" >> "${RESLIST}"

# 2. package the resource files in reslist.txt in a shared library
"$ICUBIN/pkgdata" -r 0.0 --bldopt "${BLDOPT}" --name "${MSG_BASENAME}" -v --mode dll -s "${DSTDIR}" -d "${DSTDIR}" "${RESLIST}"

# 3. platform specific processing of output file create by pkgdata
MSG_LIBBASENAME="lib${MSG_BASENAME}"
if [ "${UNAME}" = "AIX" ] ; then
  ar ${XARFLAGS} "${DSTDIR}/${MSG_LIBBASENAME}0.0.a" "${DSTDIR}/${MSG_LIBBASENAME}0.0.so"
  mv "${DSTDIR}/${MSG_LIBBASENAME}0.0.so" "${DSTDIR}/${MSG_LIBBASENAME}.${MSGEXT}"
elif [ "${UNAME}" = "HP-UX" ] ; then
  ln -f "${DSTDIR}/${MSG_LIBBASENAME}.sl.0.0" "${DSTDIR}/${MSG_LIBBASENAME}.${MSGEXT}"
else
  ln -f "${DSTDIR}/${MSG_LIBBASENAME}.${MSGEXT}.0.0" "${DSTDIR}/${MSG_LIBBASENAME}.${MSGEXT}"
fi

# 4. cleanup tempory files created by pkgdata
rm -f "${DSTDIR}/${MSG_BASENAME}_dat.o" "${DSTDIR}/${MSG_BASENAME}_dll.mak"  "${DSTDIR}/${MSG_BASENAME}_dll.lst"
rm -f "${DSTDIR}/${MSG_BASENAME}_dat.c" "${DSTDIR}/*_res.o"
# 5. delete reslist.txt and the resource files
rm -f  "${RESLIST}"
rm -f "${DSTDIR}"/root.res
rm -f "${DSTDIR}"/en.res



