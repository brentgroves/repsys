/*  rolexhound.c - file event watcher for flexutils
    Copyright (C) 2024  hoff.industries

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>. */

// WARNING!!!!
// THIS CODE SUCKS!!!
// I WHIPPED IT UP QUICKLY TO TEST THE SOCKET SERVER
// IT HAS NOT UNDERGONE QA

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <libgen.h>

#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/inotify.h>
#include <sys/epoll.h>

#include "libflex.h"

#define EXT_ERR_INIT_INOTIFY 1
#define EXT_ERR_ADD_WATCH 2
#define EXT_ERR_READ_INOTIFY 3
#define EXT_ERR_SOCKET 4
#define EXT_ERR_BIND 5
#define EXT_ERR_LISTEN 6
#define EXT_ERR_ACCEPT 7
#define EXT_ERR_ESTABLISH_CONN 11
#define EXT_ERR_CONSTRUCT_NOTIF 12
#define EXT_ERR_BASE_PATH_NULL 13

#define PORT 5521
#define MAX_FILES 10

int IeventQueue = -1;
int IeventDescriptor = -1;

struct watchEntry {
	char *watchPath;
	char *basePath;
	int wd;
};

void watch_entry_factory(struct watchEntry *entry) {
	entry->watchPath = NULL;
	entry->basePath = NULL;
	entry->wd = 0;
}

/* Catch shutdown signals so we can
 * cleanup exit properly */
void sig_shutdown_handler(int signal) {
	int closeStatus;

	printf("Exit signal received!\nclosing inotify descriptors...\n");

	// don't need to check if they're valid because
	// the signal handlers are registered after they're created;
	// we can assume they are set up correctly.
	if (IeventDescriptor != -1) {

		closeStatus = inotify_rm_watch(IeventQueue, IeventDescriptor);
		if (closeStatus == -1) {
			fprintf(stderr, "Error removing file from inotify watch!\n");
		}
	}

	close(IeventQueue);
	exit(EXIT_SUCCESS);
}

int main(int argc, char **argv) {

	char inotifyBuffer[4096];
	uint8_t socketBuffer[FLX_PKT_MAXIMUM_SIZE];

	//char *programTitle = "rolexhound";
	int readLength = 0;

	const struct inotify_event* watchEvent;

	const uint32_t watch_flags = IN_CREATE | IN_DELETE |
		IN_ACCESS | IN_CLOSE_WRITE | IN_MODIFY | IN_MOVE_SELF;

	int socketFd = -1;
	int bytesRead = -1;

	int epollFd = -1;
	int eventsReady = -1;

	struct watchEntry watchEntries[MAX_FILES];

	struct sockaddr_in serverAddress;

	struct flex_msg *readMsg, *sendMsg;
	struct serialize_result *result;

	struct epoll_event ievent, socketEvent, epollEvents[10];

	IeventQueue = inotify_init();

	if (IeventQueue == -1) {
		fprintf(stderr, "Error initialising event queue!\n");
		exit(EXT_ERR_INIT_INOTIFY);
	}

	for (int i = 0; i < MAX_FILES; i++) {
		watch_entry_factory(&watchEntries[i]);
	}

	// register signal handlers, note we
	// have already checked all error states
	signal(SIGABRT, sig_shutdown_handler);
	signal(SIGINT, sig_shutdown_handler);
	signal(SIGTERM, sig_shutdown_handler);

	socketFd = socket(AF_INET, SOCK_STREAM, 0);

	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = inet_addr(argv[1]);
	serverAddress.sin_port = htons(PORT);

	if (connect(socketFd, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == -1) {
		fprintf(stderr, "Error connecting to rolexhound with params %s %d!\n", argv[1], PORT);
		exit(EXT_ERR_ESTABLISH_CONN);
	}

	epollFd = epoll_create1(0);

	ievent.events = EPOLLIN;
	ievent.data.fd = IeventQueue;

	socketEvent.events = EPOLLIN;
	socketEvent.data.fd = socketFd;

	epoll_ctl(epollFd, EPOLL_CTL_ADD, IeventQueue, &ievent);
	epoll_ctl(epollFd, EPOLL_CTL_ADD, socketFd, &socketEvent);

	readMsg = (struct flex_msg *)malloc(sizeof(struct flex_msg));
	flex_msg_factory(readMsg);

	sendMsg = (struct flex_msg *)malloc(sizeof(struct flex_msg));
	flex_msg_factory(sendMsg);

	result = (struct serialize_result *)malloc(sizeof(struct serialize_result));
	serialize_result_factory(result);

	sendMsg->action = FLX_ACT_STATUS;
	sendMsg->option = FLX_STATUS_REG_ROLEXHOUND;
	sendMsg->size = 0;
	serialize(socketBuffer, sendMsg, result);
	write(socketFd, socketBuffer, sizeof(socketBuffer));

	// daemon main loop
	while (true) {

		eventsReady = epoll_wait(epollFd, epollEvents, 10, -1);

		for (int i = 0; i < eventsReady; i++) {

			if (epollEvents[i].data.fd == IeventQueue) {
						// block on inotify event read
				printf("Waiting for ievent...\n");
				readLength = read(IeventQueue, inotifyBuffer, sizeof(inotifyBuffer));

				if (readLength == -1) {
					fprintf(stderr, "Error reading from inotify event!\n");
					exit(EXT_ERR_READ_INOTIFY);
				}

				// one read could yield multiple events; loop through all
				// kinda tricky to get at a glance but basically moves the pointer
				// through the buffer according to the length of the inotify_event struct
				// and the length of the previous inotify event data
				for (char *buffPointer = inotifyBuffer; buffPointer < inotifyBuffer + readLength;
					buffPointer += sizeof(struct inotify_event) + watchEvent->len) {

					flex_msg_factory(sendMsg);
					watchEvent = (const struct inotify_event *) buffPointer;

					if (watchEvent->mask & IN_CREATE) {
						sendMsg->option = FLX_NOTIFY_CREATE;
					}

					if (watchEvent->mask & IN_DELETE) {
						sendMsg->option = FLX_NOTIFY_DELETE;
					}

					if (watchEvent->mask & IN_ACCESS) {
						sendMsg->option = FLX_NOTIFY_ACCESS;
					}

					if (watchEvent->mask & IN_CLOSE_WRITE) {
						sendMsg->option = FLX_NOTIFY_CLOSE;
					}

					if (watchEvent->mask & IN_MODIFY) {
						sendMsg->option = FLX_NOTIFY_MODIFY;
					}

					if (watchEvent->mask & IN_MOVE_SELF) {
						sendMsg->option = FLX_NOTIFY_MOVE;
					}

					if (sendMsg->option == FLX_UNSET_UNSET) {
						continue;
					}

					sendMsg->action = FLX_ACT_NOTIFY;
					sendMsg->dataLen = FLX_DLEN_NOTIFY;

					sendMsg->data = (char **)malloc(sizeof(char *)*FLX_DLEN_NOTIFY);

					for (int j = 0; j < MAX_FILES; j++) {
						if (watchEntries[j].wd == watchEvent->wd) {
							sendMsg->data[0] = watchEntries[j].basePath;
							sendMsg->data[1] = watchEntries[j].watchPath;
							break;
						}
					}

					bzero(socketBuffer, FLX_PKT_MAXIMUM_SIZE);

					serialize(socketBuffer, sendMsg, result);
					if (result->reply != FLX_REPLY_VALID) {
						fprintf(stderr, "Error %x constructing watch notification!\n", result->reply);
						exit(EXT_ERR_CONSTRUCT_NOTIF);
					}

					printf("Sent a notification to smartwatch!\n");
					write(socketFd, socketBuffer, FLX_PKT_MAXIMUM_SIZE);

					free(sendMsg->data);

				}

				continue;
			}

			bytesRead = read(socketFd, socketBuffer, sizeof(socketBuffer));
			if (bytesRead == 0 || bytesRead == -1) {
				exit(0);
			}

			deserialize(socketBuffer, readMsg, result);
			if (result->reply != FLX_REPLY_VALID) {
				printf("bad deserialize\n");
				continue;
			}

			printf("%d\n", readMsg->action);
			printf("%d\n", readMsg->option);

			switch (readMsg->action) {
				case FLX_ACT_WATCH:

					for (int j = 0; j < MAX_FILES; j++) {
						if (watchEntries[j].watchPath != NULL && readMsg->option == FLX_WATCH_ADD) {
							continue;
						}

						if (watchEntries[j].watchPath == NULL && readMsg->option == FLX_WATCH_REM) {
							continue;
						}

						if (readMsg->option == FLX_WATCH_ADD) {
							watchEntries[j].watchPath = strdup(readMsg->data[0]);
							watchEntries[j].basePath = strdup(basename(readMsg->data[0]));
							watchEntries[j].wd = inotify_add_watch(IeventQueue, 	watchEntries[j].watchPath, watch_flags);
						}

						if (readMsg->option == FLX_WATCH_REM && !strcmp(watchEntries[j].watchPath, readMsg->data[0])) {
							printf("REMOVING\n");
							free(watchEntries[j].watchPath);
							watchEntries[j].watchPath = NULL;
							free(watchEntries[j].basePath);
							watchEntries[j].basePath = NULL;
							inotify_rm_watch(IeventQueue, watchEntries[j].wd);
							watchEntries[j].wd = 0;
						}
						break;
					}

					break;
			}

		}
	}
}
